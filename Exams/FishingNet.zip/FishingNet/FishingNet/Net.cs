﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace FishingNet
{
    public class Net
    {

        public Net(string material, int capacity)
        {
            Material = material;
            Capacity = capacity;
        }
        public string Material { get; set; }
        public int Capacity { get; set; }

        public readonly List<Fish> Fish = new List<Fish>();

        public int Count
        {
            get
            {
                return Fish.Count;
            }
            
        }

        public string AddFish(Fish fish)
        {
            if (this.Fish.Count < this.Capacity)
            {
                if (string.IsNullOrEmpty(fish.FishType) || fish.Weight <= 0 || fish.Length <= 0)
                {
                    return $"Invalid fish.";
                }
                else
                {
                    this.Fish.Add(fish);
                    return $"Successfully added {fish.FishType} to the fishing net.";
                }
            }

            return $"Fishing net is full.";
        }

        public bool ReleaseFish(double weight)
        {
            foreach (var fish in this.Fish)
            {
                if(fish.Weight == weight)
                {
                    this.Fish.Remove(fish);
                    return true;
                }
            }

            return false;
        }

        public Fish GetFish(string fishType)
        {
            return this.Fish.FirstOrDefault(fish => fish.FishType == fishType);
        }

        public Fish GetBiggestFish()
        {
            return this.Fish.OrderByDescending(x => x.Length).First();
        }

        public string Report()
        {
            return $"Into the {Material}: {Environment.NewLine}{string.Join(Environment.NewLine, this.Fish.OrderByDescending(x => x.Length))}";
        }
    }
}
