﻿using System;
using System.Collections.Generic;

namespace Drones
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
