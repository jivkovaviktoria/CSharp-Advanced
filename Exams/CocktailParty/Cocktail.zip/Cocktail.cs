﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CocktailParty
{
    class Cocktail
    {
        private List<Ingredient> ingredients;

        public Cocktail(string name, int capacity, int maxAlcohollevel)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.MaxAlcoholLevel = maxAlcohollevel;
            this.Ingredients = new List<Ingredient>();

        }
        public List<Ingredient> Ingredients { get { return this.Ingredients = ingredients; } set { this.ingredients = value; } }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int MaxAlcoholLevel { get; set; }
        public int CurrentAlcoholLevel { get { return this.Ingredients.Select(x => x.Alcohol).Sum(); } }

        public void Add(Ingredient ingredient)
        {
            var currIngredient = Ingredients.FirstOrDefault(x => x.Name == ingredient.Name);
            if (Ingredients.Count < Capacity && currIngredient == null && CurrentAlcoholLevel+ingredient.Alcohol <= MaxAlcoholLevel)
            {
                Ingredients.Add(ingredient);
            }
        }


        public bool Remove(string name)
        {
            var ingredientToRemove = Ingredients.FirstOrDefault(x => x.Name == name);
            if (ingredientToRemove == null)
            {
                return false;
            }
            Ingredients.Remove(ingredientToRemove);
            return true;
        }


        public Ingredient FindIngredient(string name)
        {
            var findIngredient = Ingredients.FirstOrDefault(x => x.Name == name);
            if (findIngredient == null)
            {
                return null;
            }
            return findIngredient;
        }


        public Ingredient GetMostAlcoholicIngredient()
        {
            var currAlcoholicIngredient = Ingredients.OrderByDescending(x => x.Alcohol).FirstOrDefault();
            return currAlcoholicIngredient;
        }


        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Cocktail: {this.Name} - Current Alcohol Level: {this.CurrentAlcoholLevel}");
            foreach (var cocktail in Ingredients)
            {
                sb.AppendLine(cocktail.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}