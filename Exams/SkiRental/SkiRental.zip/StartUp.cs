﻿using System;

namespace SkiRental
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}