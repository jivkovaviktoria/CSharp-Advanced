﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassroomProject
{
    internal class Classroom
    {
        public Classroom(int c)
        {
            Capacity = c;
            this.Students = new List<Student>();
            students = Students;
        }
        public int Capacity { get; set; }
        public List<Student> Students { get; set; }
        private List<Student> students;
        public int Count => this.Students.Count;

        public int GetStudentsCount => Count;
        public Student GetStudent(string firstName, string lastName) => Students.Find(x => (x.FirstName == firstName)&&(x.LastName == lastName));
        public string RegisterStudent(Student student)
        {
            if(this.Students.Count < Capacity)
            {
                Students.Add(student);
                return $"Added student {student.FirstName} {student.LastName}";
            }
            else return $"No seats in the classroom";
     
        }

        public string DismissStudent(string firstName, string lastName)
        {
            var student = Students.Find(x => (x.FirstName == firstName)&&(x.LastName == lastName));
            if (student == null) return "Student not found";
            else
                Students.Remove(student);

            return $"Dismissed student {firstName} {lastName}";
        }

        public string GetSubjectInfo(string subject)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Subject: {subject}");
            sb.AppendLine("Students:");
            var students = Students.Where(x => x.Subject == subject);
            if (students.Count() == 0) return "No students enrolled for the subject";

            foreach (var x in students)
                sb.AppendLine($"{x.FirstName} {x.LastName}");

            return sb.ToString().TrimEnd();
        }
    }
}
