﻿using System;

namespace VetClinic
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}