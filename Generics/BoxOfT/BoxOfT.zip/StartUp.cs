﻿using System;

namespace BoxOfT
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
