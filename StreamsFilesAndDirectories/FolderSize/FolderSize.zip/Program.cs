﻿using System.IO;
using System.Linq;

namespace FolderSize 
{
    public class FolderSize 
    {
        static void Main() 
        {
            string folderPath = @"..\..\..\Files\TestFolder";
            string outputPath = @"..\..\..\Files\output.txt";
            
            GetFolderSize(folderPath, outputPath); 
        }
        public static void GetFolderSize(string folderPath, string outputFilePath) 
        {
            DirectoryInfo info = new DirectoryInfo(folderPath);
            long totalSize = info.EnumerateFiles().Sum(file => file.Length);

            using (StreamWriter writer = new StreamWriter(outputFilePath))
            {
                writer.Write(totalSize);
            }
        }
    }
}